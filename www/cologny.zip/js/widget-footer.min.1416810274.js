/*
 * Looking for the full, uncompressed source? Try here:
 *
 * https://github.com/nprapps/template-form
 *
 * The following files are included in this compressed version:
 *
 * www/js/widget.js
 */
